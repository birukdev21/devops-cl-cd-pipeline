'use client';

import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  BarChart,
  Bar,
  Tooltip as RechartsTooltip,
} from 'recharts';
import {
  CheckCircle2,
  XCircle,
  Clock,
  GitCommit,
  GitBranch,
  Activity,
  Zap,
  Container,
  Rocket,
  TestTube2,
  FileWarning,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Timer,
  Layers,
  ExternalLink,
  RefreshCw,
  Search,
  Filter,
  Server,
  Globe,
  Shield,
  ArrowUpDown,
  ChevronDown,
  Copy,
  MonitorSmartphone,
  CircleDot,
  Loader2,
} from 'lucide-react';

// ─── Mock Data ───────────────────────────────────────────────
const latestBuild = {
  id: '#12',
  commit: 'feat: add Docker multi-stage build',
  branch: 'main',
  status: 'passed' as const,
  triggeredBy: 'push',
  startedAt: '2025-01-15T10:32:00Z',
  duration: '2m 14s',
  pipeline: 'ci-cd',
  author: 'devops-bot',
  sha: 'a3f8c1d',
};

const recentBuilds = [
  { id: '#12', commit: 'feat: add Docker multi-stage build', branch: 'main', status: 'passed' as const, time: '2 min ago', triggeredBy: 'push', duration: '2m 14s', author: 'devops-bot' },
  { id: '#11', commit: 'fix: correct health endpoint response', branch: 'main', status: 'passed' as const, time: '1 hour ago', triggeredBy: 'push', duration: '1m 58s', author: 'devops-bot' },
  { id: '#10', commit: 'test: add integration test suite', branch: 'feature/tests', status: 'passed' as const, time: '3 hours ago', triggeredBy: 'pull_request', duration: '2m 05s', author: 'qa-engineer' },
  { id: '#9', commit: 'refactor: extract middleware layer', branch: 'main', status: 'failed' as const, time: '5 hours ago', triggeredBy: 'push', duration: '3m 41s', author: 'devops-bot' },
  { id: '#8', commit: 'chore: update dependencies to latest', branch: 'main', status: 'passed' as const, time: '8 hours ago', triggeredBy: 'push', duration: '2m 30s', author: 'devops-bot' },
  { id: '#7', commit: 'feat: add rate limiting middleware', branch: 'feature/rate-limit', status: 'passed' as const, time: '12 hours ago', triggeredBy: 'pull_request', duration: '2m 12s', author: 'backend-dev' },
  { id: '#6', commit: 'docs: update README with badges', branch: 'main', status: 'passed' as const, time: '1 day ago', triggeredBy: 'push', duration: '1m 45s', author: 'docs-team' },
  { id: '#5', commit: 'ci: add parallel job optimization', branch: 'main', status: 'passed' as const, time: '1 day ago', triggeredBy: 'push', duration: '1m 30s', author: 'devops-bot' },
  { id: '#4', commit: 'fix: resolve ESLint configuration', branch: 'main', status: 'passed' as const, time: '2 days ago', triggeredBy: 'push', duration: '2m 00s', author: 'devops-bot' },
  { id: '#3', commit: 'feat: initial pipeline setup', branch: 'main', status: 'passed' as const, time: '3 days ago', triggeredBy: 'push', duration: '2m 22s', author: 'devops-bot' },
  { id: '#2', commit: 'chore: initialize project structure', branch: 'main', status: 'passed' as const, time: '4 days ago', triggeredBy: 'push', duration: '1m 55s', author: 'devops-bot' },
  { id: '#1', commit: 'init: scaffold Express application', branch: 'main', status: 'passed' as const, time: '5 days ago', triggeredBy: 'push', duration: '2m 10s', author: 'devops-bot' },
];

const pipelineStages = [
  { name: 'Lint', icon: FileWarning, status: 'completed' as const, duration: '8s', description: 'ESLint code quality checks', logs: '✓ 0 errors, 0 warnings' },
  { name: 'Test', icon: TestTube2, status: 'completed' as const, duration: '45s', description: 'Jest unit & integration tests', logs: '✓ 4/4 tests passed' },
  { name: 'Build', icon: Container, status: 'completed' as const, duration: '1m 12s', description: 'Docker image build', logs: '✓ Image built (node:18-alpine)' },
  { name: 'Deploy', icon: Rocket, status: 'completed' as const, duration: '9s', description: 'Render deployment simulation', logs: '✓ Deployment successful' },
];

const stats = [
  { label: 'Total Builds', value: '12', icon: Layers, change: '+3 this week', trend: 'up' as const },
  { label: 'Success Rate', value: '91.7%', icon: TrendingUp, change: '+2.4%', trend: 'up' as const },
  { label: 'Avg Duration', value: '2m 14s', icon: Timer, change: '-18s faster', trend: 'up' as const },
  { label: 'Pipelines', value: '3', icon: Zap, change: '1 active', trend: 'neutral' as const },
];

const buildActivityData = [
  { day: 'Mon', builds: 3, passed: 2, failed: 1 },
  { day: 'Tue', builds: 5, passed: 5, failed: 0 },
  { day: 'Wed', builds: 2, passed: 1, failed: 1 },
  { day: 'Thu', builds: 4, passed: 4, failed: 0 },
  { day: 'Fri', builds: 6, passed: 5, failed: 1 },
  { day: 'Sat', builds: 1, passed: 1, failed: 0 },
  { day: 'Sun', builds: 2, passed: 2, failed: 0 },
];

const buildDurationData = [
  { day: 'Mon', duration: 145 },
  { day: 'Tue', duration: 128 },
  { day: 'Wed', duration: 162 },
  { day: 'Thu', duration: 118 },
  { day: 'Fri', duration: 134 },
  { day: 'Sat', duration: 115 },
  { day: 'Sun', duration: 120 },
];

const environments = [
  {
    name: 'Production',
    url: 'deployflow-ci.onrender.com',
    status: 'healthy' as const,
    lastDeploy: '2 min ago',
    version: 'v1.0.0',
    uptime: '99.9%',
    icon: Globe,
    color: 'emerald',
  },
  {
    name: 'Staging',
    url: 'staging.deployflow-ci.onrender.com',
    status: 'healthy' as const,
    lastDeploy: '15 min ago',
    version: 'v1.1.0-beta',
    uptime: '99.7%',
    icon: MonitorSmartphone,
    color: 'blue',
  },
  {
    name: 'Docker Local',
    url: 'localhost:3000',
    status: 'running' as const,
    lastDeploy: 'Just now',
    version: 'latest',
    uptime: '--',
    icon: Container,
    color: 'teal',
  },
];

const activityLog = [
  { action: 'Build #12 passed', detail: 'Docker image built successfully', time: '2 min ago', type: 'success' },
  { action: 'Build #12 deployed', detail: 'Deployed to production via Render', time: '2 min ago', type: 'success' },
  { action: 'Build #11 passed', detail: 'All 4 tests passed in 45s', time: '1 hour ago', type: 'success' },
  { action: 'Build #9 failed', detail: 'Test suite: 3/4 passed, 1 failure in middleware', time: '5 hours ago', type: 'error' },
  { action: 'PR merged: feature/rate-limit', detail: 'Merged by backend-dev', time: '11 hours ago', type: 'info' },
  { action: 'Build #5 completed', detail: 'CI pipeline optimized — 30s faster', time: '1 day ago', type: 'success' },
];

// ─── Components ──────────────────────────────────────────────

function DeployFlowLogo({ size = 'default' }: { size?: 'default' | 'large' }) {
  const svgSize = size === 'large' ? 'w-16 h-8' : 'w-12 h-6';
  return (
    <svg viewBox="0 0 48 20" fill="none" xmlns="http://www.w3.org/2000/svg" className={svgSize}>
      <circle cx="6" cy="10" r="5" fill="url(#dflow)" />
      <path d="M11 10H16" stroke="url(#dflow)" strokeWidth="2" />
      <circle cx="24" cy="10" r="5" fill="url(#dflow)" />
      <path d="M29 10H34" stroke="url(#dflow)" strokeWidth="2" />
      <circle cx="42" cy="10" r="5" fill="url(#dflow)" />
      <defs>
        <linearGradient id="dflow" x1="0" y1="0" x2="48" y2="0" gradientUnits="userSpaceOnUse">
          <stop stopColor="#2563EB" />
          <stop offset="1" stopColor="#14B8A6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function StatusBadge({ status }: { status: 'passed' | 'failed' | 'running' | 'pending' }) {
  const variants: Record<string, { className: string; label: string; icon: React.ElementType }> = {
    passed: { className: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20', label: 'Passed', icon: CheckCircle2 },
    failed: { className: 'bg-red-500/15 text-red-400 border-red-500/30 hover:bg-red-500/20', label: 'Failed', icon: XCircle },
    running: { className: 'bg-blue-500/15 text-blue-400 border-blue-500/30 hover:bg-blue-500/20', label: 'Running', icon: Loader2 },
    pending: { className: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/20', label: 'Pending', icon: Clock },
  };
  const v = variants[status] || variants.passed;
  const Icon = v.icon;
  return (
    <Badge variant="outline" className={`${v.className} gap-1`}>
      <Icon className="w-3 h-3" />
      {v.label}
    </Badge>
  );
}

function StatCard({ label, value, icon: Icon, change, trend, delay }: {
  label: string; value: string; icon: React.ComponentType<{ className?: string }>;
  change: string; trend: 'up' | 'down' | 'neutral'; delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="relative overflow-hidden border-border/50 hover:border-primary/30 transition-all duration-300 group hover:shadow-lg hover:shadow-primary/5">
        <div className="absolute top-0 right-0 w-28 h-28 bg-gradient-to-bl from-primary/8 to-transparent rounded-bl-full group-hover:from-primary/12 transition-colors duration-300" />
        <div className="absolute bottom-0 left-0 w-16 h-16 bg-gradient-to-tr from-primary/4 to-transparent rounded-tr-full" />
        <CardContent className="p-5 relative">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground font-medium">{label}</p>
              <p className="text-3xl font-bold tracking-tight bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text">{value}</p>
              <p className={`text-xs font-medium flex items-center gap-1 ${
                trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-red-400' : 'text-muted-foreground'
              }`}>
                {trend === 'up' ? <TrendingUp className="w-3 h-3" /> : trend === 'down' ? <TrendingDown className="w-3 h-3" /> : null}
                {change}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-primary/10 text-primary group-hover:bg-primary/15 group-hover:scale-110 transition-all duration-300">
              <Icon className="w-5 h-5" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function PipelineStageVisualizer() {
  const [activeStage, setActiveStage] = useState<string | null>(null);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
    >
      <Card className="border-border/50 overflow-hidden">
        <div className="h-px bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent" />
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Pipeline Execution</CardTitle>
              <CardDescription>Build #{latestBuild.id} — {latestBuild.pipeline}</CardDescription>
            </div>
            <Badge variant="outline" className="border-emerald-500/30 text-emerald-400 bg-emerald-500/10 gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              All Stages Passed
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pb-6">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-0 justify-between">
            {pipelineStages.map((stage, index) => {
              const Icon = stage.icon;
              const isActive = activeStage === stage.name;
              return (
                <div key={stage.name} className="flex items-center w-full sm:w-auto">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.4, delay: 0.4 + index * 0.15 }}
                          onClick={() => setActiveStage(isActive ? null : stage.name)}
                          className={`flex flex-col items-center gap-2 px-4 py-3 rounded-xl border cursor-pointer transition-all duration-300 ${
                            isActive
                              ? 'bg-emerald-500/20 border-emerald-500/40 shadow-lg shadow-emerald-500/10'
                              : 'bg-emerald-500/8 border-emerald-500/15 hover:bg-emerald-500/15 hover:border-emerald-500/25'
                          } sm:min-w-[110px]`}
                        >
                          <div className={`p-2.5 rounded-xl transition-colors duration-300 ${isActive ? 'bg-emerald-500/25' : 'bg-emerald-500/12'}`}>
                            <Icon className={`w-5 h-5 transition-colors duration-300 ${isActive ? 'text-emerald-300' : 'text-emerald-400'}`} />
                          </div>
                          <div className="text-center">
                            <p className={`text-sm font-semibold transition-colors duration-300 ${isActive ? 'text-emerald-200' : 'text-emerald-300'}`}>{stage.name}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 font-mono">{stage.duration}</p>
                          </div>
                          <div className={`w-2 h-2 rounded-full transition-colors duration-300 ${isActive ? 'bg-emerald-300 pulse-dot' : 'bg-emerald-400/60'}`} />
                        </motion.div>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="text-xs max-w-[220px]">
                        <p className="font-medium">{stage.name}</p>
                        <p className="text-muted-foreground">{stage.description}</p>
                        <p className="text-emerald-400 mt-1 font-mono">{stage.logs}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  {index < pipelineStages.length - 1 && (
                    <div className="hidden sm:flex items-center mx-1.5">
                      <div className="w-6 h-px bg-gradient-to-r from-emerald-500/30 to-emerald-500/10" />
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-500/30 -ml-0.5" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <div className="flex sm:hidden flex-col items-center mt-2 gap-1">
            {pipelineStages.slice(0, -1).map((_, i) => (
              <ArrowRight key={i} className="w-4 h-4 text-emerald-500/30 rotate-90" />
            ))}
          </div>
          <AnimatePresence>
            {activeStage && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 overflow-hidden"
              >
                <div className="p-3 rounded-lg bg-muted/30 border border-border/30 font-mono text-xs text-muted-foreground">
                  {activeStage} — {pipelineStages.find(s => s.name === activeStage)?.logs}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function LatestBuildCard() {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(latestBuild.sha);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, []);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
    >
      <Card className="border-border/50 overflow-hidden">
        <div className="h-1 pipeline-gradient" />
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/20">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Latest Build</CardTitle>
                <CardDescription>
                  Build #{latestBuild.id} — {latestBuild.commit}
                </CardDescription>
              </div>
            </div>
            <StatusBadge status={latestBuild.status} />
          </div>
        </CardHeader>
        <CardContent className="pb-5">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            <div className="flex items-center gap-2 text-sm">
              <GitBranch className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-muted-foreground text-xs">Branch</p>
                <code className="text-sm font-mono font-medium">{latestBuild.branch}</code>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-muted-foreground text-xs">Duration</p>
                <p className="font-medium">{latestBuild.duration}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <GitCommit className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-muted-foreground text-xs">SHA</p>
                <button onClick={handleCopy} className="font-mono text-sm font-medium hover:text-primary transition-colors flex items-center gap-1">
                  {latestBuild.sha}
                  <AnimatePresence mode="wait">
                    {copied ? (
                      <motion.span initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.5 }} key="check">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      </motion.span>
                    ) : (
                      <motion.span initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.5 }} key="copy">
                        <Copy className="w-3 h-3" />
                      </motion.span>
                    )}
                  </AnimatePresence>
                </button>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Activity className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-muted-foreground text-xs">Trigger</p>
                <p className="font-medium capitalize">{latestBuild.triggeredBy}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-muted-foreground text-xs">Pipeline</p>
                <p className="font-medium">{latestBuild.pipeline}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function BuildHistoryTable() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [branchFilter, setBranchFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'time' | 'id'>('time');

  const uniqueBranches = Array.from(new Set(recentBuilds.map(b => b.branch)));

  const filteredBuilds = recentBuilds
    .filter(b => {
      if (searchQuery && !b.commit.toLowerCase().includes(searchQuery.toLowerCase()) && !b.id.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (statusFilter !== 'all' && b.status !== statusFilter) return false;
      if (branchFilter !== 'all' && b.branch !== branchFilter) return false;
      return true;
    })
    .sort((a, b) => sortBy === 'id' ? parseInt(b.id.slice(1)) - parseInt(a.id.slice(1)) : 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.5 }}
    >
      <Card className="border-border/50">
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Build History</CardTitle>
              <CardDescription>Recent pipeline executions</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-muted-foreground gap-1">
                <BarChart3 className="w-3.5 h-3.5" />
                {filteredBuilds.length}/{recentBuilds.length} builds
              </Badge>
            </div>
          </div>
        </CardHeader>
        {/* Filters */}
        <div className="px-6 pb-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search commits or build IDs..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-9 h-9 bg-muted/30 border-border/50 text-sm"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[130px] h-9 bg-muted/30 border-border/50 text-sm">
                <Filter className="w-3.5 h-3.5 mr-1" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="passed">Passed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={branchFilter} onValueChange={setBranchFilter}>
              <SelectTrigger className="w-[140px] h-9 bg-muted/30 border-border/50 text-sm">
                <GitBranch className="w-3.5 h-3.5 mr-1" />
                <SelectValue placeholder="Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                {uniqueBranches.map(b => (
                  <SelectItem key={b} value={b}>{b}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              className="h-9 border-border/50"
              onClick={() => setSortBy(sortBy === 'time' ? 'id' : 'time')}
            >
              <ArrowUpDown className="w-3.5 h-3.5 mr-1" />
              {sortBy === 'time' ? 'Recent' : 'Build #'}
            </Button>
          </div>
        </div>
        <CardContent className="p-0">
          <div className="max-h-[440px] overflow-y-auto custom-scrollbar">
            <Table>
              <TableHeader className="sticky top-0 bg-card z-10">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[75px]">Build</TableHead>
                  <TableHead>Commit Message</TableHead>
                  <TableHead className="w-[130px]">Branch</TableHead>
                  <TableHead className="w-[85px]">Trigger</TableHead>
                  <TableHead className="w-[110px]">Status</TableHead>
                  <TableHead className="w-[90px]">Duration</TableHead>
                  <TableHead className="w-[110px]">Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBuilds.length > 0 ? filteredBuilds.map((build) => (
                  <TableRow key={build.id} className="group cursor-default transition-colors">
                    <TableCell className="font-mono font-semibold text-primary text-sm">
                      {build.id}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <GitCommit className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm truncate max-w-[280px]" title={build.commit}>
                          {build.commit}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <code className={`text-xs px-1.5 py-0.5 rounded font-mono ${build.branch === 'main' ? 'bg-primary/10 text-primary' : 'bg-muted/50 text-muted-foreground'}`}>
                        {build.branch}
                      </code>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`text-xs ${build.triggeredBy === 'push' ? 'border-border/30' : 'border-blue-500/30 text-blue-400 bg-blue-500/5'}`}>
                        {build.triggeredBy === 'push' ? 'push' : 'PR'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={build.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs font-mono">
                      {build.duration}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs">
                      {build.time}
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                      <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      <p className="text-sm">No builds match your filters</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function EnvironmentCard({ env }: { env: typeof environments[number] }) {
  const Icon = env.icon;
  const colorMap: Record<string, { dot: string; bg: string; border: string; text: string }> = {
    emerald: { dot: 'bg-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', text: 'text-emerald-400' },
    blue: { dot: 'bg-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20', text: 'text-blue-400' },
    teal: { dot: 'bg-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/20', text: 'text-teal-400' },
  };
  const c = colorMap[env.color] || colorMap.emerald;
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className={`border-border/50 hover:${c.border} transition-all duration-300 group hover:shadow-lg`}>
        <CardContent className="p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className={`p-2.5 rounded-xl ${c.bg} border ${c.border}`}>
              <Icon className={`w-5 h-5 ${c.text}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-semibold text-sm truncate">{env.name}</p>
                <div className="flex items-center gap-1">
                  <div className={`w-1.5 h-1.5 rounded-full ${c.dot} pulse-dot`} />
                  <span className={`text-xs ${c.text}`}>{env.status}</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground font-mono truncate">{env.url}</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-2 rounded-lg bg-muted/30">
              <p className="text-xs text-muted-foreground mb-0.5">Deployed</p>
              <p className="text-xs font-medium">{env.lastDeploy}</p>
            </div>
            <div className="p-2 rounded-lg bg-muted/30">
              <p className="text-xs text-muted-foreground mb-0.5">Version</p>
              <p className="text-xs font-medium font-mono">{env.version}</p>
            </div>
            <div className="p-2 rounded-lg bg-muted/30">
              <p className="text-xs text-muted-foreground mb-0.5">Uptime</p>
              <p className="text-xs font-medium">{env.uptime}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ActivityTimeline() {
  const typeStyles: Record<string, { color: string; icon: React.ElementType }> = {
    success: { color: 'text-emerald-400', icon: CheckCircle2 },
    error: { color: 'text-red-400', icon: XCircle },
    info: { color: 'text-blue-400', icon: CircleDot },
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.6 }}
    >
      <Card className="border-border/50 h-full">
        <CardHeader>
          <CardTitle className="text-lg">Activity Feed</CardTitle>
          <CardDescription>Recent pipeline events</CardDescription>
        </CardHeader>
        <CardContent className="pb-6">
          <div className="space-y-0">
            {activityLog.map((entry, i) => {
              const style = typeStyles[entry.type] || typeStyles.info;
              const Icon = style.icon;
              return (
                <div key={i} className="flex gap-3 relative">
                  {/* Timeline line */}
                  {i < activityLog.length - 1 && (
                    <div className="absolute left-[11px] top-[26px] w-px h-full bg-border/40" />
                  )}
                  <div className={`p-1.5 rounded-full bg-muted/50 border border-border/30 flex-shrink-0 relative z-10`}>
                    <Icon className={`w-3.5 h-3.5 ${style.color}`} />
                  </div>
                  <div className="flex-1 min-w-0 pb-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium">{entry.action}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{entry.detail}</p>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap flex-shrink-0">{entry.time}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function BuildActivityChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.35 }}
    >
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Build Activity</CardTitle>
          <CardDescription>Daily builds this week</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="area" className="w-full">
            <TabsList className="mb-4 bg-muted/50">
              <TabsTrigger value="area" className="text-xs gap-1">
                <Activity className="w-3 h-3" /> Volume
              </TabsTrigger>
              <TabsTrigger value="bar" className="text-xs gap-1">
                <Timer className="w-3 h-3" /> Duration
              </TabsTrigger>
            </TabsList>
            <TabsContent value="area">
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={buildActivityData}>
                    <defs>
                      <linearGradient id="colorPassed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#34d399" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#34d399" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorFailed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f87171" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#f87171" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.01 250)" opacity={0.3} />
                    <XAxis dataKey="day" tick={{ fontSize: 12, fill: 'oklch(0.65 0.01 250)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 12, fill: 'oklch(0.65 0.01 250)' }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <RechartsTooltip
                      contentStyle={{ backgroundColor: 'oklch(0.17 0.018 250)', border: '1px solid oklch(0.28 0.02 250)', borderRadius: '8px', fontSize: 12, color: 'oklch(0.94 0.005 250)' }}
                    />
                    <Area type="monotone" dataKey="passed" stroke="#34d399" fill="url(#colorPassed)" strokeWidth={2} name="Passed" />
                    <Area type="monotone" dataKey="failed" stroke="#f87171" fill="url(#colorFailed)" strokeWidth={2} name="Failed" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
            <TabsContent value="bar">
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={buildDurationData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0.01 250)" opacity={0.3} />
                    <XAxis dataKey="day" tick={{ fontSize: 12, fill: 'oklch(0.65 0.01 250)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 12, fill: 'oklch(0.65 0.01 250)' }} axisLine={false} tickLine={false} unit="s" />
                    <RechartsTooltip
                      contentStyle={{ backgroundColor: 'oklch(0.17 0.018 250)', border: '1px solid oklch(0.28 0.02 250)', borderRadius: '8px', fontSize: 12, color: 'oklch(0.94 0.005 250)' }}
                      formatter={(value: number) => [`${value}s`, 'Duration']}
                    />
                    <Bar dataKey="duration" fill="url(#barGradient)" radius={[4, 4, 0, 0]} name="Duration (s)" />
                    <defs>
                      <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#2563EB" />
                        <stop offset="100%" stopColor="#14B8A6" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function PipelineConfigCard() {
  const pipelineConfig = [
    { key: 'Trigger', value: 'push to main, pull_request', icon: Zap },
    { key: 'Node.js', value: '18.x (alpine)', icon: Server },
    { key: 'Runtime', value: 'Bun / Node.js', icon: CircleDot },
    { key: 'Linting', value: 'ESLint (recommended)', icon: FileWarning },
    { key: 'Testing', value: 'Jest + Supertest', icon: TestTube2 },
    { key: 'Container', value: 'Docker (multi-stage)', icon: Container },
    { key: 'Deploy', value: 'Render (simulated)', icon: Rocket },
  ];
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
    >
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Pipeline Configuration</CardTitle>
          <CardDescription>Current CI/CD setup parameters</CardDescription>
        </CardHeader>
        <CardContent className="pb-6">
          <div className="space-y-0">
            {pipelineConfig.map((item, i) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.key}
                  className="flex items-center justify-between py-2.5 border-b border-border/20 last:border-0 hover:bg-muted/20 -mx-2 px-2 rounded transition-colors"
                >
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5" />
                    {item.key}
                  </span>
                  <span className="text-sm font-medium font-mono text-foreground/80">{item.value}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Main Page ───────────────────────────────────────────────

export default function Home() {
  const [lastUpdated, setLastUpdated] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

    // Generate time only on client to avoid hydration mismatch
    useEffect(() => {
      setLastUpdated(new Date().toLocaleTimeString()); // eslint-disable-line react-hooks/set-state-in-effect
    }, []);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await new Promise(r => setTimeout(r, 800));
    setIsRefreshing(false);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background relative overflow-hidden noise-overlay">
      {/* Animated mesh background */}
      <div className="fixed inset-0 -z-10 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] rounded-full bg-primary/3 blur-[120px] animate-[float_20s_ease-in-out_infinite]" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-emerald-500/3 blur-[100px] animate-[float_25s_ease-in-out_infinite_reverse]" />
        <div className="absolute top-1/2 left-1/2 w-[400px] h-[400px] rounded-full bg-teal-500/2 blur-[80px] animate-[float_30s_ease-in-out_infinite]" />
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 opacity-[0.015]" style={{ backgroundImage: 'radial-gradient(circle, currentColor 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
      </div>

      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-2xl bg-background/70"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-1.5 rounded-lg bg-primary/5 border border-primary/10">
                <DeployFlowLogo size="large" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight">DeployFlow CI</h1>
                <p className="text-xs text-muted-foreground -mt-0.5">Pipeline Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/8 border border-emerald-500/15">
                <div className="w-2 h-2 rounded-full bg-emerald-400 pulse-dot" />
                <span className="text-xs font-medium text-emerald-400">All Systems Operational</span>
              </div>
              <Button variant="ghost" size="icon" className="h-9 w-9 relative" onClick={handleRefresh} disabled={isRefreshing}>
                <motion.div animate={isRefreshing ? { rotate: 360 } : { rotate: 0 }} transition={{ duration: 1, repeat: isRefreshing ? Infinity : 0, ease: 'linear' }}>
                  <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'text-primary' : 'text-muted-foreground'}`} />
                </motion.div>
              </Button>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-accent transition-colors"
                aria-label="View on GitHub"
              >
                <ExternalLink className="w-4 h-4 text-muted-foreground" />
              </a>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Stats Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat, i) => (
              <StatCard key={stat.label} {...stat} delay={0.05 * i} />
            ))}
          </div>

          {/* Latest Build */}
          <LatestBuildCard />

          {/* Pipeline Visualization + Config */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PipelineStageVisualizer />
            </div>
            <div>
              <PipelineConfigCard />
            </div>
          </div>

          {/* Charts + Environments */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <BuildActivityChart />
            </div>
            <div className="space-y-6">
              <Card className="border-border/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Pipeline Health</CardTitle>
                  <CardDescription>Overall system status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pb-5">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-muted-foreground">Success Rate</span>
                      <span className="font-semibold text-emerald-400">91.7%</span>
                    </div>
                    <Progress value={91.7} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-emerald-500 [&>div]:to-teal-500" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-muted-foreground">Test Coverage</span>
                      <span className="font-semibold text-blue-400">87.5%</span>
                    </div>
                    <Progress value={87.5} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-blue-500 [&>div]:to-blue-400" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-muted-foreground">Lint Score</span>
                      <span className="font-semibold text-teal-400">100%</span>
                    </div>
                    <Progress value={100} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-teal-500 [&>div]:to-emerald-400" />
                  </div>
                </CardContent>
              </Card>
              {/* Environments */}
              {environments.map(env => (
                <EnvironmentCard key={env.name} env={env} />
              ))}
            </div>
          </div>

          {/* Build History + Activity Feed */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <BuildHistoryTable />
            </div>
            <div className="lg:col-span-1">
              <ActivityTimeline />
            </div>
          </div>

          {/* Last updated notice */}
          {lastUpdated && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-2"
            >
              <p className="text-xs text-muted-foreground/60" suppressHydrationWarning>
                Last updated: {lastUpdated}
              </p>
            </motion.div>
          )}
        </div>
      </main>

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="mt-auto border-t border-border/30 bg-background/30 backdrop-blur-xl"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded-md bg-primary/5">
                <DeployFlowLogo />
              </div>
              <span className="text-sm text-muted-foreground">
                Pipeline powered by GitHub Actions & Docker
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="text-muted-foreground text-xs gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-[#2563EB] to-[#14B8A6]" />
                v1.1.0
              </Badge>
              <span className="text-xs text-muted-foreground">
                © 2025 DeployFlow CI
              </span>
            </div>
          </div>
        </div>
      </motion.footer>
    </div>
  );
}
