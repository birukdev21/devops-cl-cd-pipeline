import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DeployFlow CI – Modern CI/CD Pipeline Dashboard",
  description:
    "A CI/CD pipeline demonstration project with automated linting, testing, Docker build, and deployment simulation. Built with Node.js, GitHub Actions, and Docker.",
  keywords: [
    "DeployFlow",
    "CI/CD",
    "DevOps",
    "GitHub Actions",
    "Docker",
    "Pipeline",
    "Node.js",
  ],
  authors: [{ name: "DeployFlow Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "DeployFlow CI",
    description:
      "Modern CI/CD pipeline dashboard with automated linting, testing, Docker build, and deployment.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
