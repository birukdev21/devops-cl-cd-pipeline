import { NextResponse } from "next/server";

const builds = [
  { id: '#12', commit: 'feat: add Docker multi-stage build', branch: 'main', status: 'passed', time: '2 min ago', triggeredBy: 'push', duration: '2m 14s', author: 'devops-bot', sha: 'a3f8c1d' },
  { id: '#11', commit: 'fix: correct health endpoint response', branch: 'main', status: 'passed', time: '1 hour ago', triggeredBy: 'push', duration: '1m 58s', author: 'devops-bot', sha: 'b7d2e9f' },
  { id: '#10', commit: 'test: add integration test suite', branch: 'feature/tests', status: 'passed', time: '3 hours ago', triggeredBy: 'pull_request', duration: '2m 05s', author: 'qa-engineer', sha: 'c4a1f3b' },
  { id: '#9', commit: 'refactor: extract middleware layer', branch: 'main', status: 'failed', time: '5 hours ago', triggeredBy: 'push', duration: '3m 41s', author: 'devops-bot', sha: 'd8e5c2a' },
  { id: '#8', commit: 'chore: update dependencies to latest', branch: 'main', status: 'passed', time: '8 hours ago', triggeredBy: 'push', duration: '2m 30s', author: 'devops-bot', sha: 'e2f4b7c' },
  { id: '#7', commit: 'feat: add rate limiting middleware', branch: 'feature/rate-limit', status: 'passed', time: '12 hours ago', triggeredBy: 'pull_request', duration: '2m 12s', author: 'backend-dev', sha: 'f1c9a3d' },
  { id: '#6', commit: 'docs: update README with badges', branch: 'main', status: 'passed', time: '1 day ago', triggeredBy: 'push', duration: '1m 45s', author: 'docs-team', sha: 'a5b2d8e' },
  { id: '#5', commit: 'ci: add parallel job optimization', branch: 'main', status: 'passed', time: '1 day ago', triggeredBy: 'push', duration: '1m 30s', author: 'devops-bot', sha: 'b6c3e9f' },
  { id: '#4', commit: 'fix: resolve ESLint configuration', branch: 'main', status: 'passed', time: '2 days ago', triggeredBy: 'push', duration: '2m 00s', author: 'devops-bot', sha: 'c7d4a1b' },
  { id: '#3', commit: 'feat: initial pipeline setup', branch: 'main', status: 'passed', time: '3 days ago', triggeredBy: 'push', duration: '2m 22s', author: 'devops-bot', sha: 'd8e5b2c' },
  { id: '#2', commit: 'chore: initialize project structure', branch: 'main', status: 'passed', time: '4 days ago', triggeredBy: 'push', duration: '1m 55s', author: 'devops-bot', sha: 'e9f6c3d' },
  { id: '#1', commit: 'init: scaffold Express application', branch: 'main', status: 'passed', time: '5 days ago', triggeredBy: 'push', duration: '2m 10s', author: 'devops-bot', sha: 'f0a7d4e' },
];

const buildActivityData = [
  { day: 'Mon', builds: 3, passed: 2, failed: 1 },
  { day: 'Tue', builds: 5, passed: 5, failed: 0 },
  { day: 'Wed', builds: 2, passed: 1, failed: 1 },
  { day: 'Thu', builds: 4, passed: 4, failed: 0 },
  { day: 'Fri', builds: 6, passed: 5, failed: 1 },
  { day: 'Sat', builds: 1, passed: 1, failed: 0 },
  { day: 'Sun', builds: 2, passed: 2, failed: 0 },
];

const buildDurationData = [
  { day: 'Mon', duration: 145 },
  { day: 'Tue', duration: 128 },
  { day: 'Wed', duration: 162 },
  { day: 'Thu', duration: 118 },
  { day: 'Fri', duration: 134 },
  { day: 'Sat', duration: 115 },
  { day: 'Sun', duration: 120 },
];

const environments = [
  { name: 'Production', url: 'deployflow-ci.onrender.com', status: 'healthy', lastDeploy: '2 min ago', version: 'v1.0.0', uptime: '99.9%' },
  { name: 'Staging', url: 'staging.deployflow-ci.onrender.com', status: 'healthy', lastDeploy: '15 min ago', version: 'v1.1.0-beta', uptime: '99.7%' },
  { name: 'Docker Local', url: 'localhost:3000', status: 'running', lastDeploy: 'Just now', version: 'latest', uptime: '--' },
];

const stats = {
  totalBuilds: 12,
  successRate: 91.7,
  avgDuration: '2m 14s',
  pipelines: 3,
  buildsThisWeek: 3,
  successRateChange: 2.4,
  durationChange: -18,
};

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    data: {
      latestBuild: builds[0],
      builds,
      stats,
      buildActivityData,
      buildDurationData,
      environments,
      pipelineStages: [
        { name: 'Lint', status: 'completed', duration: '8s', description: 'ESLint code quality checks', logs: '0 errors, 0 warnings' },
        { name: 'Test', status: 'completed', duration: '45s', description: 'Jest unit & integration tests', logs: '4/4 tests passed' },
        { name: 'Build', status: 'completed', duration: '1m 12s', description: 'Docker image build', logs: 'Image built (node:18-alpine)' },
        { name: 'Deploy', status: 'completed', duration: '9s', description: 'Render deployment simulation', logs: 'Deployment successful' },
      ],
    },
  });
}
