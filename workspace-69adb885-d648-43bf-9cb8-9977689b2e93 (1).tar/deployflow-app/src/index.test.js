const request = require('supertest');
const app = require('./index');

describe('DeployFlow CI API', () => {
  describe('GET /health', () => {
    it('should return 200 status', async () => {
      const response = await request(app).get('/health');
      expect(response.status).toBe(200);
    });

    it('should return ok status', async () => {
      const response = await request(app).get('/health');
      expect(response.body.status).toBe('ok');
    });

    it('should return a timestamp', async () => {
      const response = await request(app).get('/health');
      expect(response.body.timestamp).toBeDefined();
    });

    it('should return version', async () => {
      const response = await request(app).get('/health');
      expect(response.body.version).toBe('1.0.0');
    });
  });
});
