# 🚀 DeployFlow CI

<p align="center">
  <strong>A CI/CD pipeline demonstration project with automated linting, testing, Docker build, and deployment simulation.</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/CI%2FCD-Passing-brightgreen?style=flat-square" alt="CI/CD" />
  <img src="https://img.shields.io/badge/GitHub%20Actions-Workflow-blue?style=flat-square&logo=github-actions" alt="GitHub Actions" />
  <img src="https://img.shields.io/badge/Docker-Containerized-2496ED?style=flat-square&logo=docker" alt="Docker" />
  <img src="https://img.shields.io/badge/Node.js-18.x-339933?style=flat-square&logo=node.js" alt="Node.js" />
  <img src="https://img.shields.io/badge/Express-4.x-000000?style=flat-square&logo=express" alt="Express" />
</p>

<p align="center">
  <a href="https://deployflow-ci.onrender.com" target="_blank">
    <img src="https://img.shields.io/badge/Live-Render-00C7B7?style=flat-square" alt="Live Deployment" />
  </a>
</p>

---

## 📋 Overview

A senior-level DevOps showcase. The repository includes a fully functional CI/CD pipeline that lints, tests, builds a Docker image, and simulates a deployment to production. The dashboard page displays the latest build status and pipeline history. This proves you understand continuous integration, containerization, and automated deployments.

## 🏗️ Repository Structure

```
deployflow-ci/
├── .github/
│   └── workflows/
│       └── ci-cd.yml          # GitHub Actions pipeline
├── src/
│   ├── index.js               # Express web app
│   └── index.test.js          # Jest tests (supertest)
├── public/
│   └── index.html             # Dashboard UI (dark theme)
├── Dockerfile                  # Multi-stage Docker build
├── package.json                # Dependencies & scripts
├── render.yaml                 # Render deployment config
├── .eslintrc.json              # ESLint configuration
└── README.md                   # You are here
```

## ⚡ Pipeline Stages

| Stage    | Tool        | Description                    |
|----------|-------------|--------------------------------|
| **Lint** | ESLint      | Code quality checks            |
| **Test** | Jest        | Unit & integration tests       |
| **Build**| Docker      | Multi-stage container build   |
| **Deploy**| Render     | Deployment simulation         |

### Pipeline Flow
```
Push/PR → Lint → Test → Build (Docker) → Deploy (Simulation)
              ↓      ↓         ↓               ↓
           ESLint  Jest    docker build     Render webhook
```

## 🚀 Quick Start

### Local Development
```bash
# Install dependencies
npm install

# Run the server
npm start

# Run tests
npm test

# Run linter
npm run lint
```

### Docker
```bash
# Build the image
docker build -t deployflow-ci .

# Run the container
docker run -p 3000:3000 deployflow-ci

# Check health
curl http://localhost:3000/health
```

## 🌐 Live Deployment

The application is deployed on [Render](https://render.com):

- **Dashboard**: [https://deployflow-ci.onrender.com](https://deployflow-ci.onrender.com)
- **Health Check**: [https://deployflow-ci.onrender.com/health](https://deployflow-ci.onrender.com/health)

## 📊 API Endpoints

| Endpoint | Method | Description              |
|----------|--------|--------------------------|
| `/`      | GET    | Dashboard UI            |
| `/health`| GET    | Health check (`{ status, timestamp, uptime, version }`) |

## 🛠️ Tech Stack

- **Runtime**: Node.js 18.x (Alpine)
- **Framework**: Express 4.x
- **Testing**: Jest + Supertest
- **Linting**: ESLint (recommended config)
- **Containerization**: Docker (multi-stage build)
- **CI/CD**: GitHub Actions
- **Deployment**: Render

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

<p align="center">
  <strong>Pipeline powered by GitHub Actions & Docker</strong>
</p>
